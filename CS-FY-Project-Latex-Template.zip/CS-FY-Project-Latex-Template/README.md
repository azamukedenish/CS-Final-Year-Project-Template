LaTeX templates for Undergraduate research
---------------------------------

Format adapted to fit the current format used at the School of Computing, Makerere University.

It is advisable to learn the basics of LaTeX before using this template.
A good resource to start with is http://en.wikibooks.org/wiki/LaTeX/

How to Start
============

Start editing with report.tex and the corresponding LaTeX files in the /tex folder.

Revision History
================

### Version 1 (Feb-2018)
1. Draft 1 template for report.
2. Modular way of developing content 
3. Examples given for citing and inserting references and footnotes.


License
=======
<a rel="license" href="http://creativecommons.org/licenses/by/4.0/"><img alt="Creative Commons License" style="border-width:0" src="https://i.creativecommons.org/l/by/4.0/80x15.png" /></a><br /><span xmlns:dct="http://purl.org/dc/terms/" property="dct:title">LaTeX Template for Project Report</span> by Ernest Mwebaze is licensed under a <a rel="license" href="http://creativecommons.org/licenses/by/4.0/">Creative Commons Attribution 4.0 International License</a>.
